#include "GameObject.h"

GameObject::GameObject(LPCWSTR filename)
{
	position = { 0,0 };
	scale = { 1,1 };
	angle = 0.0;
	Graphic::Load_Bitmap(this, filename);
}

GameObject::~GameObject()
{
}
