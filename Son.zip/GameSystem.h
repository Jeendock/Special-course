#pragma once

enum SceneType
{
	INTRO,
	MAIN,
	GAME,
	EXIT
};

class GameSystem
{
public:
	void Init();
	void Update();
	void Render();
	void Release();
};