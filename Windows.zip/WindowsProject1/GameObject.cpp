#include "GameObject.h"

GameObject::GameObject(LPCWSTR filename)
{
}

GameObject::~GameObject()
{
}
