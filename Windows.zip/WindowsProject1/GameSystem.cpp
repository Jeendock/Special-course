#include "GameSystem.h"

void GameSystem::Init()
{
}

void GameSystem::Update()
{
}

void GameSystem::Render()
{
}

void GameSystem::Release()
{
}
