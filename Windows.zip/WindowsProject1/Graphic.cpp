#include "Graphic.h"

void Graphic::Init(HWND hwnd)
{
}

void Graphic::Load_Bitmap(LPCWSTR name)
{
}

void Graphic::Render()
{
}

void Graphic::BeginDraw()
{
}

void Graphic::EndDraw()
{
}
