#pragma once
#include <d2d1.h>
#include <wincodec.h>

class Graphic
{
private:

public:
	static void Init(HWND hwnd);
	static void Load_Bitmap(LPCWSTR name);
	static void Render();
	static void BeginDraw();
	static void EndDraw();
};
