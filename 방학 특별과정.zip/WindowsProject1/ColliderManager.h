#pragma once
#include "GameObject.h"

class ColliderManager
{
public:
	static bool BoxCollider(GameObject* obj1, GameObject* obj2);
};

