#include "GameObject.h"

GameObject::GameObject(LPCWSTR filename)
{
	position = { 0,0 };
	scale = { 1,1 };
	angle = 0.0;
	Graphic::Laod_Bit_Map(this, filename);
}

GameObject::~GameObject()
{

}
