#include "GameSystem.h"
int GameSystem::Check_Scenenumber;

void GameSystem::Init()
{
	SetScene(SCENETYPE::INTRO);
}

void GameSystem::Update()
{
	scene->Update();
}

void GameSystem::Render()
{
	scene->Render();
}

void GameSystem::Release()
{
	scene->Release();
	delete scene;
}

void GameSystem::SetScene(int sceneNumber)
{
	SceneNumber = sceneNumber;
	Check_Scenenumber = sceneNumber;
	if (scene != nullptr)
	{
		scene->Release();
		delete scene;
	}
	switch (sceneNumber)
	{
	case SCENETYPE::INTRO:
		scene = new IntroScene();
		break;
	case SCENETYPE::MAIN:
		break;
	case SCENETYPE::GAME:
		break;
	case SCENETYPE::EXIT:
		exit(0);
		break;
	}
	if (scene != nullptr)
	{
		scene->Init();
	}
}

void GameSystem::SceneChangeCheck()
{
	if (SceneNumber != Check_Scenenumber)
	{
		SetScene(Check_Scenenumber);
	}
}

