#pragma once
#include "Scene.h"
#include "IntroScene.h"

enum SCENETYPE
{
	INTRO,
	MAIN,
	GAME,
	EXIT,
};

class GameSystem
{
private:
	Scene* scene = nullptr;
	int SceneNumber;
public:
	static int Check_Scenenumber;
public:
	void Init();
	void Update();
	void Render();
	void Release();
	void SetScene(int sceneNumber);
	void SceneChangeCheck();
};

