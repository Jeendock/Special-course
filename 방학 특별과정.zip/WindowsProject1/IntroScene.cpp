#include "IntroScene.h"

void IntroScene::Init()
{
	background = new GameObject(L"./Res/back.jpg");
	background->position = { 0,0 };
}

void IntroScene::Update()
{
}

void IntroScene::Render()
{
	Graphic::Render(background);
}

void IntroScene::Release()
{
	delete background;
}
