#pragma once
#include "Scene.h"
#include "GameSystem.h"
#include "Graphic.h"

class IntroScene : public Scene
{
private:
	GameObject* background;
public:
	void Init();
	void Update();
	void Render();
	void Release();
};

